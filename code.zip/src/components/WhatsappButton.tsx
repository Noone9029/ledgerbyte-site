import WhatsAppIcon from "@/assets/logos/whatsapp.svg";

const WhatsAppButton = () => {
  const phoneNumber = "971561371569";
  const message = "Hello! I’d like to learn more about your services.";

  return (
    <a
      href={`https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="
        fixed right-5 bottom-5 z-50
        flex items-center justify-center
        h-14 w-14 rounded-full
        bg-[#25D366] shadow-lg hover:shadow-xl
        transition-all duration-300
        focus:outline-none focus:ring-2 focus:ring-[#128C7E]
      "
    >
      <img
        src={WhatsAppIcon}
        alt="WhatsApp"
        className="w-10 h-10 object-contain"
      />
    </a>
  );
};

export default WhatsAppButton;
